import { useEffect, useRef, useState } from 'react';
import useAuth from '../../../hooks/useAuth';
import { dyslexiaService } from '../services/dyslexiaService';
import { DYSLEXIA_STAR_EVENT, DYSLEXIA_STAR_VISIBILITY_EVENT } from '../components/DyslexiaStarCounter';

const createRewardRunId = () => {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
};

/**
 * Connects a dyslexia game lifecycle to the session backend.
 * Tracking is deliberately best-effort: a backend outage must never block a child from playing.
 */
export default function useDyslexiaGameSession({
  gameKey,
  level = 1,
  totalQuestions = 0,
  started,
  finished,
  score = 0,
  rewardSourceRect = null,
}) {
  const { user } = useAuth();
  const userId = user?.uid || user?.id;
  const [sessionId, setSessionId] = useState(null);
  const startingRef = useRef(false);
  const completedRef = useRef(false);
  const startedAtRef = useRef(null);
  const previousScoreRef = useRef(0);
  const rewardRunIdRef = useRef(createRewardRunId());

  // Every dyslexia game shares the same reward visibility lifecycle:
  // hidden before start, visible while playing, hidden on the result screen.
  useEffect(() => {
    window.dispatchEvent(new CustomEvent(DYSLEXIA_STAR_VISIBILITY_EVENT, {
      detail: { visible: Boolean(started && !finished) },
    }));
    return () => {
      window.dispatchEvent(new CustomEvent(DYSLEXIA_STAR_VISIBILITY_EVENT, {
        detail: { visible: false },
      }));
    };
  }, [finished, started]);

  // A retry normally returns the game to its intro/start state before beginning again.
  // Clear the previous run so the next play creates a distinct backend session.
  useEffect(() => {
    if (started) return;
    setSessionId(null);
    startingRef.current = false;
    completedRef.current = false;
    startedAtRef.current = null;
    previousScoreRef.current = 0;
    rewardRunIdRef.current = createRewardRunId();
  }, [started]);

  // Some games restart directly from their result screen without returning to
  // an intro state. Prepare a fresh reward identity for that next run too.
  useEffect(() => {
    if (finished) rewardRunIdRef.current = createRewardRunId();
  }, [finished]);

  // A score increase represents a positive action in every Dyslexia game.
  useEffect(() => {
    const safeScore = Number.isFinite(Number(score)) ? Number(score) : 0;
    if (started && safeScore > previousScoreRef.current) {
      window.dispatchEvent(new CustomEvent(DYSLEXIA_STAR_EVENT, {
        detail: {
          gameKey,
          level,
          score: safeScore,
          userId,
          sourceRect: rewardSourceRect,
          rewardRunId: rewardRunIdRef.current,
        },
      }));
    }
    previousScoreRef.current = safeScore;
  }, [gameKey, level, rewardSourceRect, score, started, userId]);

  useEffect(() => {
    if (!started || finished || !userId || sessionId || startingRef.current) return;

    startingRef.current = true;
    startedAtRef.current = Date.now();
    dyslexiaService.startSession({ userId, gameKey, level, totalQuestions })
      .then((response) => setSessionId(response?.data?.id ?? null))
      .catch(() => { /* gameplay remains available offline */ })
      .finally(() => { startingRef.current = false; });
  }, [finished, gameKey, level, sessionId, started, totalQuestions, userId]);

  useEffect(() => {
    if (!finished || !sessionId || !userId || completedRef.current) return;

    completedRef.current = true;
    const safeScore = Number.isFinite(Number(score)) ? Number(score) : 0;
    const safeTotal = Number.isFinite(Number(totalQuestions)) ? Number(totalQuestions) : 0;
    const correctAnswers = Math.max(0, Math.min(safeTotal, safeScore));

    dyslexiaService.completeSession(sessionId, {
      userId,
      status: 'completed',
      score: safeTotal > 0 ? Math.round((correctAnswers / safeTotal) * 100) : safeScore,
      totalQuestions: safeTotal,
      correctAnswers,
      wrongAnswers: Math.max(0, safeTotal - correctAnswers),
      durationSeconds: startedAtRef.current
        ? Math.max(0, Math.round((Date.now() - startedAtRef.current) / 1000))
        : 0,
    }).catch(() => { /* gameplay remains available offline */ });
  }, [finished, score, sessionId, totalQuestions, userId]);

  return sessionId;
}
